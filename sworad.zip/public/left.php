<?php 
        $postcounter=0;
        $adcounter=0;
        
        ?>
                                  
        <?php 
            function create_slug($string)        {
         $slug=preg_replace('/[^A-Za-z0-9-]+/', '_', $string);
         return $slug; 	
            }
           
        ?>        
        <!-- Page Container -->
        <div class="w3-container w3-content" style="max-width:1400px;margin-top:80px">
            <!-- The Grid -->
            <div class="w3-row">
                <!-- Left Column -->
                <div class="w3-col m3 l3">
                    <!-- Profile --><b class="w3-red w3-padding-small">Popular Post</b>
                    <div class=" w3-bottombar w3-border-red w3-col s12 m12 l12"> </div>
                <?php 
    $query=@unserialize (file_get_contents('http://ip-api.com/php/'));
    if($query && $query['status']== 'success'){
    $timezone=$query['timezone'];
    date_default_timezone_set("Asia/Kathmandu");
    }
    
    

 foreach ($ppost as $pp){
	
	


 
 if($postcounter==4 && $adcounter<5){
    	?>
    	<div class="w3-card w3-round w3-white w3-padding-small">
    	Ads here
    	</div>
    	<br>
    
    <?php $postcounter=0;
    	$adcounter++;}
    ?>
                   <a href="content.php?title=<?php echo $pp['slug']; ?>"style="text-decoration:none"> 
                   <div class="w3-card w3-round w3-white w3-padding-small">
                   
             <?php
           $img= $pp['image'];
        
        
        if (!empty($img)) {
        	
       echo '<img class="thumb" src="'. $img.' "style= "width:100%" alt="Image Not Avilable">';
     
        }
     
         ?>
              
                   
                        <?php echo $pp['title']; ?>
                    </div></a>
                    <br>
                    <?php $postcounter++;
                    
                    }
                       ?>
                   
                              
                              
                    <!-- End Left Column -->
                </div>