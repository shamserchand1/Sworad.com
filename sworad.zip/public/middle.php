 <!-- Middle Column -->
                <div class="w3-col m6">
                    <div class="w3-row-padding">
             <?php 
        $fcounter=0;
        $fadcounter=0;
        
        ?>
   <?php foreach ($fpost as $fpost){ ?>
                   
            <?php 
    if($fcounter==3 && $fadcounter<5){
    	?>
    	<div class="w3-card w3-round w3-white w3-padding-small">
    	Ads here
    	</div>
    	<br>
    <?php $fcounter=0;
    	$fadcounter++;}
    ?>            
                           <a href="content.php?title=<?php echo $fpost['slug']; ?>" style="text-decoration:none"><div class="w3-container w3-card w3-white w3-round w3-margin-bottom ">
                                
                               
                                
                     
     
        <span class="w3-right w3-opacity">On:-
        
        <?php $time=strtotime($fpost['time']);
        echo date('d/m/Y H:i', $time); ?>
        
        </span>
        <h4><b><?php echo $fpost['title'];
         
        
         ?></h4></b>
        
        <?php
        $img=$fpost['image'];
        
        if (!empty($img)) {
        	
       echo '<img class="thumb" src="'. $img.' "style= "width:100%" alt="Image Not Avilable">';
     
        }
     
         ?>
        
        
        <?php echo $fpost['disc']; ?>
          <div class="w3-row-padding" style="margin:0 -16px">
            
              
         
            
        </div>
        
                     
                     
                  </div>
                  </a>
                  <?php $fcounter++;?>
                  <?php } ?>
               </div>
               <!-- End Middle Column -->
            </div>