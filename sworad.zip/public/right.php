<!-- Right Column -->
            <div class="w3-col m3">
               <div class="w3-card w3-round w3-white w3-center">
                  <div class="w3-container">
                     <h4 class="w3-red">Follow Us On</h4>
                     <a href="https://www.facebook.com/thesworad/" class="so fa fa-facebook"></a>
                     <a href="#" class="so fa fa-twitter"></a>
                     <a href="#" class="so fa fa-linkedin"></a>
                     <a href="#" class="so fa fa-youtube"></a>
                     <a href="#" class="so fa fa-instagram"></a>
                     <a href="#" class="so fa fa-pinterest"></a>
                  </div>
               </div>
               <br> 
               <div class="w3-card w3-round w3-white w3-padding-16 w3-center">
                  <p>ADS</p>
               </div>
               <br>
               <b class="w3-red w3-padding-small">Recent Post</b>
               <div class=" w3-bottombar w3-border-red w3-col s12 m12 l12"> </div>
               <div class="w3-white w3-round w3-card">
                  <ul class="w3-ul w3-padding-small">
 
 <?php foreach ($rpost as $rp){
                     
             ?>        
                     <li>
                    <a href="content/<?php echo $rp['slug']; ?>" style="text-decoration:none">  <?php echo $rp['title']; ?></a>
                     </li>
                     
                    <?php } ?>
                     
                  </ul>
               </div>
               <br>
               <div class="w3-card w3-round w3-white w3-padding-16 w3-center">
                 <div id="fb-root"></div> <script>(function(d, s, id) { var js, fjs = d.getElementsByTagName(s)[0]; if (d.getElementById(id)) return; js = d.createElement(s); js.id = id; js.src = "//connect.facebook.net/en_US/sdk.js#xfbml=1&version=v2.5&appId={APP_ID}"; fjs.parentNode.insertBefore(js, fjs); }(document, 'script', 'facebook-jssdk'));</script>     
                   <div class="fb-page" data-href="https://www.facebook.com/thesworad/" data-tabs="timeline" data-small-header="false" data-adapt-container-width="true" data-hide-cover="false" data-show-facepile="true"> <div class="fb-xfbml-parse-ignore"> <blockquote cite="https://www.facebook.com/facebook"> <a href="https://www.facebook.com/facebook">Facebook</a> </blockquote> </div> </div>
                   
                   
                             </div>
               <br>
               <!-- End Right Column -->
            </div>
            <!-- End Grid -->
         </div>
         <!-- End Page Container -->
      </div>
      <br>