<!DOCTYPE html>
    <html>

    <head>
        <title>Sworad.com is the hub for trending news, blogs and tips and tutorials about information technology,science.with over 5 million users per month</title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="description" content="It is a platform where every people who are interested in the information technology and science can find their every necessary materials related to science, information Technology, history, current affairs, etc such as updates related to his along with news and blog also in this website. It is the place which could be like the golden collection for those of whom are preparing for the lok sewa aayog examination. It is the website which is visited by over 5 million people per month.">
        
        <meta name="og:title" content="Sworad.com is the hub for trending news, blogs and tips and tutorials about information technology,science.with over 5 million users per month"/> 
        <meta name="og:type" content="website"/> 
        <meta name="og:url" content="https://sworad.com"/> 
        <meta name="og:image" content="http://sworad.com/upload/banner.jpg"/> 
        <meta name="og:site_name" content="Sworad.com"/> 
        <meta name="og:description" content="It is a platform where every people who are interested in the information technology and science can find their every necessary materials related to science, information Technology, history, current affairs, etc such as updates related to his along with news and blog also in this website. It is the place which could be like the golden collection for those of whom are preparing for the lok sewa aayog examination. It is the website which is visited by over 5 million people per month..."/> 


        <meta name="keywords" content="HTML,CSS,XML,JavaScript,Computer,MCQ,loksewa, nepal,Excel,word,powerpoint">
        <meta name="author" content="Shamser Chand">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
        <link rel="stylesheet" href="/style.css">
        <link rel="stylesheet" href="https://www.w3schools.com/lib/w3-theme-blue-grey.css">
        <link rel='stylesheet' href='https://fonts.googleapis.com/css?family=Open+Sans'>
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
        <style>
            html,
            body,
            h1,
            h2,
            h3,
            h4,
            h5 {
                font-family: "Open Sans", sans-serif
            }
            
            .margin-bottom:last-child {
                margin-bottom: 0px;
            }
            
            .margin-bottom {
                margin-bottom: 5px;
            }
            
            html,
            body,
            h1,
            h2,
            h3,
            h4,
            h5 {
                font-family: "Open Sans", sans-serif
            }
            img{
            	max-width:100% !important;
            	height:auto !important;
            	}
            
            .so {
                padding: 10px;
                font-size: 30px;
                width: 50px;
                text-align: center;
                text-decoration: none;
                margin: 5px 2px;
            }
            
            .fa:hover {
                opacity: 0.7;
            }
            
            .fa-facebook {
                background: #3B5998;
                color: white;
            }
            
            .fa-twitter {
                background: #55ACEE;
                color: white;
            }
            
            .fa-google {
                background: #dd4b39;
                color: white;
            }
            
            .fa-linkedin {
                background: #007bb5;
                color: white;
            }
            
            .fa-youtube {
                background: #bb0000;
                color: white;
            }
            
            .fa-instagram {
                background: #125688;
                color: white;
            }
            
            .fa-pinterest {
                background: #cb2027;
                color: white;
            }
            
            .fa-snapchat-ghost {
                background: #fffc00;
                color: white;
                text-shadow: -1px 0 black, 0 1px black, 1px 0 black, 0 -1px black;
            }
            
            .fa-skype {
                background: #00aff0;
                color: white;
            }
            
            .fa-android {
                background: #a4c639;
                color: white;
            }
            
            .fa-dribbble {
                background: #ea4c89;
                color: white;
            }
            
            .fa-vimeo {
                background: #45bbff;
                color: white;
            }
            
            .fa-tumblr {
                background: #2c4762;
                color: white;
            }
            
            .fa-vine {
                background: #00b489;
                color: white;
            }
            
            .fa-foursquare {
                background: #45bbff;
                color: white;
            }
            
            .fa-stumbleupon {
                background: #eb4924;
                color: white;
            }
            
            .fa-flickr {
                background: #f40083;
                color: white;
            }
            
            .fa-yahoo {
                background: #430297;
                color: white;
            }
            
            .fa-soundcloud {
                background: #ff5500;
                color: white;
            }
            
            .fa-reddit {
                background: #ff5700;
                color: white;
            }
            
            .fa-rss {
                background: #ff6600;
                color: white;
            }
            
            .small-font {
                font-size: 8px;
            }
            .thumb{
            	max-height: 200px !important;
            	object-fit:cover;
            }
        </style>
    </head>

    <body class="w3-theme-l5">
    
        <!-- Navbar -->
        <div class="w3-top">
            <div class="w3-bar w3-blue w3-left-align w3-large">
                <a class="w3-bar-item w3-button w3-hide-medium w3-hide-large w3-right w3-padding-large w3-hover-white w3-large w3-blue" href="javascript:void(0);" onclick="openNav()">
                    <i class="fa fa-bars"></i></a>
                <a href="https://sworad.com" class="w3-bar-item w3-button w3-padding-large w3-blue">
                    <i class="fa fa-home w3-margin-right"></i>Sworad.com</a>
                <?php $sql_query="SELECT * FROM Nav"; $result=mysqli_query($mysqli,$sql_query); while($row=mysqli_fetch_row($result)) { ?>
                    <a href="https://sworad.com/<?php echo $row[0]; ?>.php" class="w3-bar-item w3-button w3-hide-small w3-padding-large w3-hover-white" title="<?php echo $row[0]; ?>">
                        <?php echo $row[0]; ?>
                    </a>
                    <?php } ?>
            </div>
        </div>
        </div>
        <!-- Navbar on small screens -->
        <div id="navDemo" class="w3-bar-block w3-light-blue w3-hide w3-hide-large w3-hide-medium w3-large">
            <a href="https://sworad.com" class="w3-bar-item w3-button w3-padding-large">Link 1</a>
            <?php $sql_query="SELECT * FROM Nav"; $result=mysqli_query($mysqli,$sql_query); while($row=mysqli_fetch_row($result)) { ?>
                 <a href="https://sworad.com/<?php echo $row[0]; ?>.php" class="w3-bar-item w3-button w3-padding-large w3-hover-white" title="<?php echo $row[0]; ?>">
                    <?php echo $row[0]; ?>
                </a>
                <?php } ?>
                   
        </div>