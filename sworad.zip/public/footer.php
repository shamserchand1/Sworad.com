<!-- Footer -->
      <footer class="w3-container w3-theme-d3 w3-padding-16">
         <h3 class=" w3-center">Who We are?</h3>
         <p>
            We are a group of young and enthusiastic people in pursuit of knowledge just like you. 
            We understand your struggle of searching hudreds of websites in preparation of Loksewa. Sworad.com is a hub where
            you will find News, Blogs, Tips and Tutorials about Information Technology, Science and Loksewa. Thanks to your support, we know
            have over 5 million people visiting us every month.
            So, what are you waiting for? Hurry up and devour everything we have to offer.
             
         </p>
         
      </footer>
      <footer class="w3-container w3-theme-d5 w3-center">
         <p>© <?php $copyYear = 2019; 
         // Set your website start date 
         $curYear = date('Y');
          // Keeps the second year updated 
          echo $copyYear . (($copyYear != $curYear) ? '-' . $curYear : ''); ?> 
         <a href="https://www.sworad.com" target="_blank" style="text-decoration:none;">Sworad.com</a> All rights reserved</p>
      </footer>
      <script>
         // Accordion 
         function myFunction(id) {
             var x = document.getElementById(id);
             if (x.className.indexOf("w3-show") == -1) {
                 x.className += " w3-show";
                 x.previousElementSibling.className += " w3-theme-d1";
             } else {
                 x.className = x.className.replace("w3-show", "");
                 x.previousElementSibling.className = x.previousElementSibling.className.replace(" w3-theme-d1", "");
             }
         } // Used to toggle the menu on smaller screens when clicking on the menu button 
         function openNav() {
             var x = document.getElementById("navDemo");
             if (x.className.indexOf("w3-show") == -1) {
                 x.className += " w3-show";
             } else {
                 x.className = x.className.replace(" w3-show", "");
             }
         }
      </script>
   </body>
</html>