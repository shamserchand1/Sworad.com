<?php

$ppost=array();
$fpost=array();
$rpost=array();

$popular="(SELECT * FROM News where featured=1) UNION ALL (SELECT * FROM Definition where featured=1) UNION ALL (SELECT * FROM Tutorial where featured=1) order by rand(views) desc limit 15"; 

$featured="(SELECT * FROM News where featured=1) UNION ALL (SELECT * FROM Definition where featured=1) UNION ALL (SELECT * FROM Tutorial where featured=1) order by rand(time) desc"; 
 
$recent="(SELECT * FROM News where featured=1) UNION ALL (SELECT * FROM Definition where featured=1) UNION ALL (SELECT * FROM Tutorial where featured=1) order by rand(time) desc limit 15";  
                 $result_set=mysqli_query($mysqli,$featured); 
                        while($row=mysqli_fetch_assoc($result_set)) {
            $fpost[]=$row; 
                }   
                
                 $result_set=mysqli_query($mysqli,$popular); 
                        while($row=mysqli_fetch_assoc($result_set)) {
            $ppost[]=$row; 
                }  
                
$result_set=mysqli_query($mysqli,$recent); 
                 while($row=mysqli_fetch_assoc($result_set)) {
            $rpost[]=$row; 
                }     
                   ?>