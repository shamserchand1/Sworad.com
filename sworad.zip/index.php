<!-- Include fuction--!>
<?php
include_once 'public/db_connect.php';

include_once 'public/fetch.php';

include_once 'public/header.php';

include_once 'public/left.php';

include_once 'public/middle.php';

include_once 'public/right.php';

include_once 'public/footer.php';


	
 ?>
 